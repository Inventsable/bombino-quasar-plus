<template>
  <q-page class="main-page">
    <sadface />
    <span style="width: 100%;" class="text-center q-pt-xl"
      >I have no content yet</span
    >
  </q-page>
</template>

<script>
export default {
  components: {
    sadface: require("src/assets/sadLogo.vue").default
  }
};
</script>

<style></style>
